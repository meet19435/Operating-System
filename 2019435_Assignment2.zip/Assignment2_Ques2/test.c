/* Name: Meet Modi
   Roll_Number: 2019435 */
#define _GNU_SOURCE
#include <unistd.h>
#include <sys/syscall.h>
#include <stdio.h>
#include <sys/types.h>
#include <errno.h>
#include <string.h>
#include <stdlib.h>

#define SYS_sh_task_info 441

int main()
{
	int num_err;
	char *way="/home/meetmodi1/Output.txt";
	int id=getpid();
	int call=syscall(SYS_sh_task_info,id,way);
	printf("The PID IS %d\n",id);
	printf("The system call returned %d\n",call);
	if(call!=0)
	{
		num_err=abs(call);
		printf("Error Encountered: %s\n",strerror(num_err));
		return 1;	
	}
	return 0;
}
