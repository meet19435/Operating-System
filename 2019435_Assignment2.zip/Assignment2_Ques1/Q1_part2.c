/* Name: Meet Modi
   Roll_Number: 2019435 */

#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <stdlib.h>
#include <pthread.h>
int test_var;
void *test_fun(void *var)
{	
	int *d=(int *)var;
	while(*d>-90)
	{
		*d=*d-1;
		printf("%d ",*d);
	}
	printf("\n-----\n");
	printf("The final Value after Thread is %d \n",*d);
	return NULL;
}
void *parent_fun(int *test_var)
{
	while(*test_var<100)
	{
		*test_var=*test_var+1;
		printf("%d ",*test_var);
	}
	printf("\n-----\n");
	printf("The final Value after Parent Process %d \n",*test_var);
	return NULL;
}
void main()
{	test_var=10;
	pthread_t tid;
	printf("Before the Execution Of Thread\n");
	pthread_create(&tid,NULL,test_fun,(void *)&test_var);		
	parent_fun(&test_var);
	pthread_join(tid,NULL);
	printf("After The Execution of Thread\n");
	exit(0);

}
