/* Name: Meet Modi
   Roll_Number: 2019435 */

#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <stdlib.h>
int test_var;
int main()
{	pid_t id=fork();
	test_var=10;
	if(id>0)
	{	wait(NULL);
		for(int i=0;i<90;i++)
		{
			test_var=test_var+1;
		}
		printf("The final value after Parent process: %d \n",test_var);
	}
	else if(id==0)
	{
		for(int i=0;i<100;i++)
		{
			test_var=test_var-1;
		}
		printf("The final value after Child Process: %d \n",test_var);
		exit(0);
	}
	else
	{
		perror("Cannot Create Child Process");	
	}
	return 0;

}
