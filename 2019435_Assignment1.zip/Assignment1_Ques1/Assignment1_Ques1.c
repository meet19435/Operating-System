
#include <stdio.h>
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>
#include<sys/wait.h> 
#include<unistd.h> 
int main()
{	
	char inputfile[20];
	scanf("%s",inputfile);
	pid_t pro=fork();	
	if(pro==0)
	{	printf("Child Process Begins\n");
		int fd1=0;
		int s1=0;
		fd1=open(inputfile,O_RDONLY);
		if(fd1==-1)
		{
			perror("File Not Found");
			exit(1);
		}
		char *c=(char *)calloc(10000,sizeof(char));
		s1=read(fd1,c,10000);
		if(s1==-1)
		{
			perror("File Not Found");
			exit(1);
		}
		char *p=strtok(c," \n");
		int i=0;
		while(i<7)
		{
			//printf("%s\n",p);
			p=strtok(NULL," \n");
			i=i+1;
		}
		printf("ID   SECTION\tAVERAGE\n");
		i=0;
		double sum=0;
		char *section;
		char * id;
		while(p!=NULL)
		{
			if(i==0)
			{
				id=p;
			}
			else if(i==1)
			{
				section=p;
			}
			else if(i==2)
			{
				double testsum=atoi(p);
				sum=sum+testsum;
			}
			else if(i==3)
			{
				double testsum=atoi(p);
				sum=sum+testsum;
			}
			else if(i==4)
			{
				double testsum=atoi(p);
				sum=sum+testsum;
			}
			else if(i==5)
			{
				double testsum=atoi(p);
				sum=sum+testsum;
				if(*section=='A')
				{
					printf("%s\t%s\t%.2f\n",id,section,sum/4);
				}
				i=0;
				sum=0;
				p=strtok(NULL," \n");
				continue;
			}
			i=i+1;
			p=strtok(NULL," \n");
		}
		c[s1]='\0';
		printf("CHILD PROCESS FINISHED\n");
		exit(0);
	}
	else if(pro>0)
	{	waitpid(pro,NULL,0);
		printf("Parent Process Begins\n");			
		int fd1=0;
		int s11=0;
		fd1=open(inputfile,O_RDONLY);
		if(fd1==-1)
		{
			perror("File Not Found");
			exit(1);
		}
		char *c1=(char *)calloc(10000,sizeof(char));
		s11=read(fd1,c1,10000);
		if(s11==-1)
		{
			perror("File Not Found");
			exit(1);
		}
		char *p1=strtok(c1," \n");
		int i1=0;
		while(i1<7)
		{
			//printf("%s\n",p);
			p1=strtok(NULL," \n");
			i1=i1+1;
		}
		printf("ID   SECTION\tAVERAGE\n");
		i1=0;
		double sum1=0;
		char *section1;
		char * id1;
		while(p1!=NULL)
		{
			if(i1==0)
			{
				id1=p1;
			}
			else if(i1==1)
			{
				section1=p1;
			}
			else if(i1==2)
			{
				double testsum1=atoi(p1);
				sum1=sum1+testsum1;
			}
			else if(i1==3)
			{
				double testsum1=atoi(p1);
				sum1=sum1+testsum1;
			}
			else if(i1==4)
			{
				double testsum1=atoi(p1);
				sum1=sum1+testsum1;
			}
			else if(i1==5)
			{
				double testsum1=atoi(p1);
				sum1=sum1+testsum1;
				if(*section1=='B')
				{
					printf("%s\t%s\t%.2f\n",id1,section1,sum1/4);
				}
				i1=0;
				sum1=0;
				p1=strtok(NULL," \n");
				continue;
			}
			i1=i1+1;
			p1=strtok(NULL," \n");
		}
		c1[s11]='\0';
		printf("PARENT PROCESS FINISHED\n");

	}
	else
	{
		perror("Child Process Cannot be Created");
	}
	return 0;
}
