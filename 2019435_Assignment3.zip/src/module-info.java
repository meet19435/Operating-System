module Mafia {
}