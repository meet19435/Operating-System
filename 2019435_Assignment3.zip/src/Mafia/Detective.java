package Mafia;

public class Detective extends Player{
	public Detective(int id)
	{
		super(id);
		this.setHp(800);
		this.setType("Detective");
	
	}
}
