package Mafia;
import java.util.*;
public class SelectCharacter{
	protected Player user;
	protected StartGame sg;
	Random r=new Random();
	Scanner in1=new Scanner(System.in);
	public SelectCharacter(StartGame sg)
	{	this.sg=sg;
		this.select();
	}
	public void select()
	{
		System.out.println("CHOOSE A CHARACTER");
		System.out.println("1)Mafia");
		System.out.println("2)Detective");
		System.out.println("3)Healer");
		System.out.println("4)Commoner");
		System.out.println("5)Assign Randomly");
		int cn=sg.in1.nextInt();
		if(cn==1)
		{
			int test=r.nextInt(sg.getm().size());
			user=sg.getm().out(test);
			RunMafia rm=new RunMafia(sg,this);
			rm.Run();
		}
		else if(cn==2)
		{
			int test=r.nextInt(sg.getd().size());
			user=sg.getd().out(test);
			RunDetective rd=new RunDetective(sg,this);
			rd.Run();
		}
		else if(cn==3)
		{
			int test=r.nextInt(sg.geth().size());
			user=sg.geth().out(test);
			RunHealer rd=new RunHealer(sg,this);
			rd.Run();
		}
		else if(cn==4)
		{
			int test=r.nextInt(sg.getc().size());
			user=sg.getc().out(test);
			RunCommoner rd=new RunCommoner(sg,this);
			rd.Run();
		}
		else if(cn==5)
		{
			int test=r.nextInt(sg.getp().size());
			user=sg.getp().out(test);
			System.out.println(user.getType());
			mafia m1=new mafia(0);
			Detective m2=new Detective(0);
			Healer m3=new Healer(0);
			if(user.equals(m1))
			{
				RunMafia rm=new RunMafia(sg,this);
				rm.Run();
			}
			else if(user.equals(m2))
			{
				RunDetective rm=new RunDetective(sg,this);
				rm.Run();
			}
			else if(user.equals(m3))
			{
				RunHealer rm=new RunHealer(sg,this);
				rm.Run();
			}
			else
			{
				RunCommoner rd=new RunCommoner(sg,this);
				rd.Run();
			}
		}
		else
		{
			System.out.println("Invalid Option");
			this.select();
		}
		
	}
}
