package Mafia;

public class Player {
	private final int id;
	private String type;
	private double hp;
	private boolean evicted;
	public Player(int id)
	{
		this.id=id;
		this.type="Commoner";
		this.hp=1000;
		this.evicted=false;
	}
	protected boolean getE()
	{
		return this.evicted;
	}
	protected int getId()
	{
		return this.id;
	}
	protected String getType()
	{
		return this.type;
	}
	protected double getHp()
	{
		return this.hp;
	}
	protected void setHp(int n)
	{
		this.hp=n;
	}
	protected void setType(String type)
	{
		this.type=type;
	}
	protected void incHp(double n)
	{
		this.hp=this.hp+n;
	}
	protected void decHp(double n)
	{
		this.hp=this.hp-n;
		if(this.hp<0)
		{
			this.hp=0;
		}
	}
	protected void setE(boolean b)
	{
		this.evicted=b;
	}
	@Override
	public boolean equals(Object o)
	{
		if(o!=null && getClass()==o.getClass())
		{
			Player p1=(Player)o;
			return (this.type==p1.getType());
		}
		else
		{
			return false;
		}
	
	}
}
