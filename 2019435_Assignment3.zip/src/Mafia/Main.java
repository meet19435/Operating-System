package Mafia;
public class Main {

	public static void main(String[] args) {
	
		StartGame s1=new StartGame();
		s1.start();
		SelectCharacter sc=new SelectCharacter(s1);
		
	}

}
