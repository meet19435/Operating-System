package Mafia;
import java.util.*;
public class RunHealer extends RunClass {
	protected StartGame sg;
	protected SelectCharacter sc;
	Scanner in1=new Scanner(System.in);
	public RunHealer(StartGame sg,SelectCharacter sc)
	{
		super(sg,sc);
		this.sg=sg;
		this.sc=sc;
	}
	@Override
	public void Run()
	{
		System.out.println("You are Healer Player "+sc.user.getId()+" ");
		System.out.print("Other Healers are ");
		System.out.print("[");
		for(int i=0;i<sg.geth().size();i++)
		{
			if(sg.geth().out(i).getId()!=sc.user.getId())
			{
				System.out.print("Player"+ sg.geth().out(i).getId()+" ");
			}
		}
		System.out.print("]");
		System.out.println();
		int count=0;
		while(true)
		{	int win=sg.win();
			if(win==1)
			{
				System.out.println("Mafias Have Won");
				sg.print();
				break;
			}
			else if(win==0)
			{
				System.out.println("Players Have Won");
				sg.print();
				break;
			}
			System.out.println("Round"+count+": ");
			Player selected1=null;
			Player selected2;
			Player selected3=null;
			boolean flag=false;
			System.out.print(sg.talive()+" Players Are Remaining ");
			sg.printAlive();
			System.out.println();
			double hpSum=sg.sumhp();
			if(sg.alive()>0)
			{	
				Player p=sg.randomMafia();
				selected1=p;
				double hp=p.getHp();
				p.decHp(hpSum);
				if(hpSum<p.getHp())
				{
					for(int i=0;i<sg.getm().size();i++)
					{
						sg.getm().out(i).setHp(0);
					}
				}
				else
				{
					sg.dechp(hp);
				}
				//for(int i=0;i<sg.mlist.size();i++)
				//{
					//System.out.println(sg.mlist.out(i).getHp());
				//}
				System.out.println("Mafias Have Choosen Their Target");
				
				//System.out.println(p.getHp()+" "+p.getType()+" "+p.getId());
			}
			
			
			if(sg.dalive()>0)
			{	
				System.out.println("Detectives Have Choosen Their Target");
				Player p=sg.randomDetective();
				selected3=p;
				mafia m=new mafia(0);
				if(p.equals(m))
				{	
					flag=true;
					//System.out.println("Player"+p.getId()+" was a mafia and was evicted");
				}
				
				
				
			}
			else
			{
				System.out.println("Detectives Have Choosen Their Target");
			}
			
			if(sg.halive()>0)
			{
				if(sc.user.getE())
				{
					System.out.println("Healers Have Choosen Their Target To Heal");
					Player p=sg.randomHealer();
					selected2=p;
					p.incHp(500);
					//System.out.println(p.getType()+" "+p.getId()+" "+p.getHp());
				}
				else
				{
					Player p=null;
					while(p==null)
					{
						p=sg.chooseHealer();
					}
					System.out.println("Healers Have Choosen Their Target To Heal");
					selected2=p;
					p.incHp(500);
					//System.out.println(p.getType()+" "+p.getId()+" "+p.getHp());
					
				}
			}
			else
			{
				System.out.println("Healers Have Choosen Their Target To Heal");
			}
			System.out.println("----End Of Actions----");
			if(selected1.getHp()==0)
			{
				selected1.setE(true);
				System.out.println("Player"+selected1.getId()+" has died");
			}
			int win2=sg.win();
			if(win2==1)
			{
				System.out.println("Mafias Have Won");
				sg.print();
				break;
			}
			else if(win2==0)
			{
				System.out.println("Players Have Won");
				sg.print();
				break;
			}
			if(flag)
			{	selected3.setE(true);
				System.out.println("Player"+selected3.getId()+" was a mafia and was evicted");
				System.out.println("End Of Round:"+count);
				count++;
				int win3=sg.win();
				if(win3==1)
				{
					System.out.println("Mafias Have Won");
					sg.print();
					break;
				}
				else if(win3==0)
				{
					System.out.println("Players Have Won");
					sg.print();
					break;
				}
				continue;
			}
			else
			{
				this.voting();
				int win4=sg.win();
				if(win4==1)
				{
					System.out.println("Mafias Have Won");
					sg.print();
					break;
				}
				else if(win4==0)
				{
					System.out.println("Players Have Won");
					sg.print();
					break;
				}
				System.out.println("End Of Round:"+count);
			}
			count++;
			
			
			
		}
	}
	

	}

