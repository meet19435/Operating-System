package Mafia;
import java.util.*;
public abstract class RunClass {
	private StartGame sg;
	private SelectCharacter sc;
	Scanner in1=new Scanner(System.in);
	Random r=new Random();
	public RunClass(StartGame sg,SelectCharacter sc)
	{
		this.sg=sg;
		this.sc=sc;
	}
	public abstract void Run();
	public void voting()
	{	
		ArrayList<Integer> a1=new ArrayList<Integer>();
		for(int i=0;i<=sg.getPlayer();i++)
		{
			a1.add(0);
		}
		if(sc.user.getE()==false)
		{	
			int vot=0;
			while(vot==0)
			{	System.out.print("Enter the Player To Vote Out-");
				vot=in1.nextInt();
				boolean flag=false;
				for(int i=0;i<sg.getp().size();i++)
				{
					if(sg.getp().out(i).getId()==vot && sg.getp().out(i).getE()==false)
					{
						flag=true;
					}
				}
				if(!flag)
				{	System.out.println("Player Already Evicted or Not Present");
					vot=0;
				}
				
			}
			int a=a1.get(vot);
			a=a+1;
			a1.set(vot,a);
		}
		for(int j=0;j<sg.getp().size();j++)
		{
			if(sg.getp().out(j).getE()==false && sg.getp().out(j).getId()!=sc.user.getId())
			{
				int vot=0;
				while(vot==0)
				{	vot=r.nextInt(sg.getp().size());
					boolean flag=false;
					for(int i=0;i<sg.getp().size();i++)
					{
						if(sg.getp().out(i).getId()==vot && sg.getp().out(i).getE()==false)
						{
							flag=true;
						}
					}
					if(!flag)
					{
						vot=0;
					}
				}
				int a=a1.get(vot);
				a=a+1;
				a1.set(vot,a);
		
				
		}
		
	}
	int id=0;
	int max=-1;
	for(int i=1;i<=sg.getp().size();i++)
	{
		if(a1.get(i)>max)
		{
			id=i;
			max=a1.get(i);
		}
	}
	int tcount=0;
	for(int i=1;i<=sg.getp().size();i++)
	{
		if(a1.get(i)==max)
		{
			tcount=tcount+1;
		}
	}
	if(tcount>1)
	{
		System.out.println("There was A Tie in the votes and Voting will again take place");
		this.voting();
	}
	else
	{
		for(int i=0;i<sg.getp().size();i++)
		{
			if(sg.getp().out(i).getId()==id)
			{
				sg.getp().out(i).setE(true);
				System.out.println("Player"+id+" was Voted Out");
			}
		}
		
	}
	
	
}
}
