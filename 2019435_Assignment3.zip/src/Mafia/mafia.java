package Mafia;

public class mafia extends Player {
	public mafia(int id)
	{
		super(id);
		this.setType("Mafia");
		this.setHp(2500);
	}
	
}
