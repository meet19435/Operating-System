package Mafia;
import java.util.*;
public class Stack <T> {
	private ArrayList<T> list;
	private int size;
	public Stack()
	{
		list=new ArrayList<T>();
	}
	public void in(T o)
	{
		list.add(o);
		size=size+1;;
	}
	public T out(int i)
	{
		return this.list.get(i);
	}
	public int size()
	{
		return this.size;
	}
	
}
