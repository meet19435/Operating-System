package Mafia;
import java.util.*;
public class StartGame {
	public Scanner in1=new Scanner(System.in);
	public Random r=new Random();
	private Stack<Player> olist=new Stack<Player>();
	private Stack<Detective> dlist=new Stack<Detective>();
	private Stack<mafia> mlist=new Stack<mafia>();
	private Stack<Healer> hlist=new Stack<Healer>();
	private Stack<Player> clist=new Stack<Player>();
	private int players;
	public StartGame()
	{
		
	}
	protected void start()
	{	System.out.println("Welcome To Mafia");
		System.out.print("Enter The Number Of Players-");
		players=in1.nextInt();
		while(players<6)
		{
			System.out.print("Enter The Number Of Players-");
			players=in1.nextInt();
			
		}
		int mafias=players/5;
		int detectives=players/5;
		int healers=Math.max(1,players/10);
		int commoners=players-healers-detectives-mafias;
		ArrayList<Integer> l1=new ArrayList<Integer>();
		for(int i=0;i<players;i++)
		{
			l1.add(i+1);
		}
		for(int i=0;i<mafias;i++)
		{
			int test=r.nextInt(l1.size());
			int id=l1.get(test);
			mafia m1=new mafia(id);
			l1.remove(test);
			mlist.in(m1);
			olist.in(m1);
		}
		for(int i=0;i<detectives;i++)
		{
			int test=r.nextInt(l1.size());
			int id=l1.get(test);
			Detective d1=new Detective(id);
			l1.remove(test);
			dlist.in(d1);
			olist.in(d1);

			
		}
		for(int i=0;i<healers;i++)
		{
			int test=r.nextInt(l1.size());
			int id=l1.get(test);
			Healer h1=new Healer(id);
			l1.remove(test);
			hlist.in(h1);
			olist.in(h1);

		}
		for(int i=0;i<commoners;i++)
		{
			int test=r.nextInt(l1.size());
			int id=l1.get(test);
			Player p1=new Player(id);
			l1.remove(test);
			olist.in(p1);
			clist.in(p1);
		}
		
		
	}
	protected int alive()
	{
		int count=0;
		for(int i=0;i<mlist.size();i++)
		{
			if(mlist.out(i).getE()==false)
			{
				count=count+1;
			}
		}
		return count;
	}
	protected int dalive()
	{
		int count=0;
		for(int i=0;i<dlist.size();i++)
		{
			if(dlist.out(i).getE()==false)
			{
				count=count+1;
			}
		}
		return count;
	}
	protected int halive()
	{
		int count=0;
		for(int i=0;i<hlist.size();i++)
		{
			if(hlist.out(i).getE()==false)
			{
				count=count+1;
			}
		}
		return count;
	}
	protected int talive()
	{
		int count=0;
		for(int i=0;i<olist.size();i++)
		{
			if(olist.out(i).getE()==false)
			{
				count=count+1;
			}
		}
		return count;
	}
	protected double sumhp()
	{	double sum=0;
		for(int i=0;i<mlist.size();i++)
		{
			Player test=mlist.out(i);
			if(test.getE()==false)
			{
				sum=sum+test.getHp();
			}
		}
		return sum;
	}
	protected void printAlive()
	{
		for(int j=1;j<=olist.size();j++)
		{
			for(int i=0;i<olist.size();i++)
			{
				if(olist.out(i).getE()==false && olist.out(i).getId()==j)
				{
					System.out.print("Player"+olist.out(i).getId()+" ");
				}
			}
		}
	}
	protected Player chooseMafia()
	{
		System.out.print("Choose The Target-");
		mafia m=new mafia(0);
		int n=in1.nextInt();
		Player p=null;
		for(int i=0;i<olist.size();i++)
		{
			Player test=olist.out(i);
			if(test.getId()==n)
			{
				if(test.getE())
				{
					System.out.println("Player Already Evicted");
				}
				else if(test.equals(m))
				{
					System.out.println("Cannot Select A Mafia");
				}
				else
				{
					p=test;
				}
			}
			
		}
		return p;
	}
	protected Player chooseDetective()
	{
		System.out.print("Choose The Target-");
		Detective m=new Detective(0);
		int n=in1.nextInt();
		Player p=null;
		for(int i=0;i<olist.size();i++)
		{
			Player test=olist.out(i);
			if(test.getId()==n)
			{
				if(test.getE())
				{
					System.out.println("Player Already Evicted");
				}
				else if(test.equals(m))
				{
					System.out.println("Cannot Select A Detective");
				}
				else
				{
					p=test;
				}
			}
			
		}
		return p;
	}
	protected Player chooseHealer()
	{
		System.out.print("Choose The Player To Heal-");
		Healer m=new Healer(0);
		int n=in1.nextInt();
		Player p=null;
		for(int i=0;i<olist.size();i++)
		{
			Player test=olist.out(i);
			if(test.getId()==n)
			{
				if(test.getE())
				{
					System.out.println("Player Already Evicted");
				}
				else if(test.equals(m))
				{
					System.out.println("Cannot Select A Healer");
				}
				else
				{
					p=test;
				}
			}
			
		}
		return p;
	}
	protected Player randomMafia()
	{
		int test=r.nextInt(olist.size());
		Player p=null;
		mafia m=new mafia(0);
		while(p==null)
		{	Player test1=olist.out(test);
			if(test1.equals(m)==false && test1.getE()==false)
			{
				p=test1;
				break;
			}
			else
			{
				test=r.nextInt(olist.size());			
			}
		}
		return p;
	}
	protected Player randomDetective()
	{
		int test=r.nextInt(olist.size());
		Player p=null;
		Detective m=new Detective(0);
		while(p==null)
		{	Player test1=olist.out(test);
			if(test1.equals(m)==false && test1.getE()==false)
			{
				p=test1;
				break;
			}
			else
			{
				test=r.nextInt(olist.size());			
			}
		}
		return p;
	}
	protected Player randomHealer()
	{
		int test=r.nextInt(olist.size());
		Player p=null;
		Healer m=new Healer(0);
		while(p==null)
		{	Player test1=olist.out(test);
			if(test1.equals(m)==false && test1.getE()==false)
			{
				p=test1;
				break;
			}
			else
			{
				test=r.nextInt(olist.size());			
			}
		}
		return p;
	}
	protected int win()
	{	double a=talive();
		double b=alive();
		if(alive()==0)
		{
			return 0;
		}
		else if((a-b)/b==1)
		{	
			return 1;
		}
		else if((a-b)/b==0)
		{
			return 1;
		}
		else
		{
			return -1;
		}
	}
	protected void print()
	{
		System.out.print("Mafias were ");
		for(int i=0;i<mlist.size();i++)
		{
			System.out.print("Player"+mlist.out(i).getId()+" ");
			
		}
		System.out.println();
		System.out.print("Detectives were ");
		for(int i=0;i<dlist.size();i++)
		{
			System.out.print("Player"+dlist.out(i).getId()+" ");
		
		}
		System.out.println();
		System.out.print("Healers were ");
		for(int i=0;i<hlist.size();i++)
		{
			System.out.print("Player"+hlist.out(i).getId()+" ");
			
		}
		System.out.println();
		System.out.print("Commoners were ");
		for(int i=0;i<clist.size();i++)
		{
			System.out.print("Player"+clist.out(i).getId()+" ");
			
		}
		System.out.println();
		
	}
	protected void dechp(double hp)
	{
		if(hp==0)
		{
			return ;
		}
		
		int count=0;
		for(int i=0;i<mlist.size();i++)
		{
			if(mlist.out(i).getHp()>0)
			{
				count++;
			}
		}
		if(count==0)
		{
			return;
		}
		double damage=hp/count;
		double leftdamage=0;
		for(int i=0;i<mlist.size();i++)
		{
			if(mlist.out(i).getHp()!=0)
			{
				if(mlist.out(i).getHp()>=damage)
				{
					mlist.out(i).decHp(damage);
				}
				else
				{
					leftdamage=damage-mlist.out(i).getHp();
					mlist.out(i).setHp(0);
				}
			}
		}
		dechp(leftdamage);
		
		
	}
	public Stack<mafia> getm()
	{
		return this.mlist;
	}
	public Stack<Detective> getd()
	{
		return this.dlist;
	}
	public Stack<Player> getc()
	{
		return this.clist;
	}
	public Stack<Healer> geth()
	{
		return this.hlist;
	}
	public Stack<Player> getp()
	{
		return this.olist;
	}
	public int getPlayer()
	{
		return this.players;
	}
	
	
	
	
 
}
