package Mafia;

public class Healer extends Player {
	public Healer(int id)
	{
		super(id);
		this.setHp(800);
		this.setType("Healer");
	
	}
}
