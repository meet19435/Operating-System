#include <stdio.h>

int main()
{
	char *c="Hello";
	char *b="World";
	printf(" %s ",c);
	printf(" %s ",b);
	return 0;
}