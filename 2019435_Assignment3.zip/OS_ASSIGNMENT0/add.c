#include <stdio.h>
#include <inttypes.h>

int64_t _add(int64_t,int64_t);

int main()
{
	int a;
	int b;
	scanf("%d %d",&a,&b);
	printf(" %ld ", _add(a,b));
	return 0;
}