#include <stdio.h>

int long_add(int a,int b,int c,int d);
void main()
{
	int a,b,c,d;
	a=3;
	b=9;
	c=27;
	d=81;
	int fin=long_add(a,b,c,d);
	printf("The Sum is %d \n",fin);
}
