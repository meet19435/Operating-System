#include <stdio.h>
long extended_add(long a,long b,long c,long d);

void main()
{
	int a=1;
	int b=2;
	int c=4;
	int d=8;
	printf("The sum is %ld\n",extended_add(a,b,c,d));
}
