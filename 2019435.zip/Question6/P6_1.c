#include <stdio.h>
#include <stdlib.h>
#include <string.h>
void main()
{
	char a[9]={'M','e','e','t','M','o','d','i','\0'};
	printf("%s",a);
	char *a1;
	a1=(char *)calloc(9,sizeof(char));
	strcpy(a1,a);
	printf("%s",a1);
	free(a1);



}