#include <stdio.h>

void main()
{	
	FILE *filewrite;
	filewrite=fopen("Write.dat","w");
	char a[9]={'M','e','e','t','M','o','d','i','\0'};
	for(int i=0;i<8;i++)
	{
		fputc(a[i],filewrite)	;	
	}
	fclose(filewrite);
}
