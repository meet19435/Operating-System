add(float a,float b)
{
	return (float)(round(a)+round(b));
}