
void main()
{
	char x[64];
	long int *p2;
	p2=x;
	long int arr1[8]={2,4,8,16,32,64,128,256};
	int i=0;
	for(i=0;i<8;i++)
	{
		*(p2+i)=arr1[i];
	}
	
	

}
