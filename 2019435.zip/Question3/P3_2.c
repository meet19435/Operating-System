void main()
{
	char x[64];
	int *p1;
	p1=x;
	int arr2[16]={1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1};
	int i=0;
	for(i=0;i<16;i++)
	{
		*(p1+i)=arr2[i];

	}
}