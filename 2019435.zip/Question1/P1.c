#include <stdio.h>
void CheckGreater();

int main()
{
	CheckGreater();
	return 0;
}
