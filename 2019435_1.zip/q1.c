#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <string.h>
int main()
{
	int pipe1[2];
	int pipe2[2];
	char ip[501];
	fgets(ip,501,stdin);
	if(pipe(pipe1)==-1 || pipe(pipe2)==-1)
	{
		printf("Pipe is not Working\n");
	}
	if(fork()>0)
	{
		close(pipe1[0]);
		write(pipe1[1],ip,strlen(ip)+1);
		close(pipe1[1]);
		wait(NULL);
		close(pipe2[1]);
		char from_child[501];
		read(pipe2[0],from_child,501);
		close(pipe2[0]);
		int test=0;
		while(from_child[test]!='\n')
		{
		
			printf("%c",from_child[test]);
			test=test+1;

		}
		printf("\n");
	}
	else
	{
		close(pipe1[1]);
		char from_parent[501];
		read(pipe1[0],from_parent,501);
		close(pipe1[0]);
		close(pipe2[0]);
		int test=0;
		while(from_parent[test]!='\n') 
		{
      		if(from_parent[test] >= 'a') 
      			{
         			if(from_parent[test] <= 'z')
         			{	
					
         				from_parent[test] = from_parent[test] -32;
         			}
         		}
		test=test+1;
        }
		write(pipe2[1],from_parent,strlen(from_parent)+1);
		close(pipe2[1]);
		exit(0);
	}
	return 0;

}
