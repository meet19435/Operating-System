#include <stdio.h> 
#include <sys/ipc.h>
#include <fcntl.h> 
#include <sys/msg.h>  
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
struct msg { 
	long category; 
	char mess[100]; 
} bla; 

int main() 
{ 
	key_t kt; 
	int msg_id; 
	kt = ftok("filetest.txt", 5);
	if(kt<0)
	{
		printf("Key Not Generated\n");
		return 1;
	} 
	msg_id = msgget(kt, 0666 | IPC_CREAT); 
	if(msg_id<0)
	{
		printf("Id Cannot Be Created\n");
		return 1;
	}
	bla.category = 1; 
	//fgets(bla.mess,100,stdin);
	int fd1=0;
	int s1=0;
	fd1=open("para2.txt",O_RDONLY);
	if(fd1==-1)
	{
		perror("File Not Found");
		exit(1);
	}
	char *c=(char *)calloc(1000,sizeof(char));
	s1=read(fd1,c,1000);
	if(s1==-1)
	{
		perror("File Not Found");
		exit(1);
	}
	char *p=strtok(c," ");
	while(p!=NULL)
	{
		
		strcpy(bla.mess,p);
		long test=msgsnd(msg_id, &bla, sizeof(bla), 0);
		p=strtok(NULL," ");


	} 
	strcpy(bla.mess,"\n\n");
	long test2=msgsnd(msg_id,&bla,sizeof(bla),0);
	 
	return 0; 
} 
