#include <stdio.h> 
#include <sys/ipc.h>
#include <fcntl.h> 
#include <sys/msg.h>  
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
struct msg { 
	long category; 
	char mess[100]; 
} bla; 

int main() 
{ 	FILE *file_point;
	file_point=fopen("filetest.txt","w");
	if(file_point==NULL)
	{
		printf("There we are\n");
		exit(1);	
	}
	fclose(file_point);
	key_t kt; 
	int msg_id; 
	kt = ftok("filetest.txt", 5); 
	msg_id = msgget(kt, 0666 | IPC_CREAT); 
	bla.category = 1; 
	//fgets(bla.mess,100,stdin);
	int fd1=0;
	int s1=0;
	fd1=open("para1.txt",O_RDONLY);
	if(fd1==-1)
	{
		perror("File Not Found");
		exit(1);
	}
	char *c=(char *)calloc(1000,sizeof(char));
	s1=read(fd1,c,1000);
	if(s1==-1)
	{
		perror("File Not Found");
		exit(1);
	}
	char *p=strtok(c," ");
	while(p!=NULL)
	{
		
		strcpy(bla.mess,p);
		long test=msgsnd(msg_id, &bla, sizeof(bla), 0);
		p=strtok(NULL," ");


	} 
	 
	return 0; 
} 
