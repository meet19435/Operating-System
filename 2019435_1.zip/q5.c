#include <stdio.h>
#include <sys/types.h>
#include <stdlib.h>
#include <sys/shm.h>
#include <semaphore.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/wait.h>
#include <unistd.h>
#include <pthread.h>
key_t kt;
long message_info;
long *p;
pthread_mutex_t mut;
void sh_mem()
{	
	FILE *fil=fopen("filetest.txt","w");
	kt=ftok("filetest.txt",10);
	message_info=shmget(kt,sizeof(long),0666 |IPC_CREAT);
	p=(long *)shmat(message_info,NULL,0);
	*p=-1;
	
}
void *child(int n)
{		int a=n;
		pthread_mutex_lock(&mut);
		sleep(2);
		printf("Student %d has Value from Shared Memory %ld\n",a,*p);
		pthread_mutex_unlock(&mut);
		
}
int main(){
	sh_mem();
	int child_count;
	printf("Number of Children Required\n");
	scanf("%d",&child_count);
	printf("The Value of Shared Memory Initialised to 6969\n");
	pthread_t thread_arr[child_count+1];
	*p=6969;
	int count=0;
	pthread_mutex_init(&mut,NULL);
	for(count=0;count<child_count;count++)
	{	
		pthread_create(&thread_arr[count],NULL,(void *)child,(int *)count);
		
	}
	for(count=0;count<child_count;count++)
	{
		pthread_join(thread_arr[count],NULL);
	}
	pthread_mutex_destroy(&mut);
	shmdt(p);
	shmctl(message_info,IPC_RMID,0);
		
	return 0;
}