#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/shm.h>
#include <semaphore.h>
#include <sys/wait.h>
#include <string.h>
#include <fcntl.h>
int main()
{	
	FILE *file_point;
	file_point=fopen("filetest.txt","w");
	if(file_point==NULL)
	{
		printf("There we are\n");
		exit(1);	
	}
	fclose(file_point);
	sem_t *sem_str=sem_open("q41_sem",O_CREAT|O_EXCL,0666,1);
	sem_unlink("q41_sem");
	key_t kt1;
	key_t kt2; 
	int msg_id; 
	kt1 = ftok("filetest.txt", 5);
	kt2= ftok("filetest.txt",6);
	if(fork()==0)
	{	sem_wait(sem_str);
		int msg_info1=shmget(kt1,500,0666 | IPC_CREAT);
		int msg_info2=shmget(kt2,500,0666 | IPC_CREAT);
		//printf("%d\n",msg_info);
		char *bla1=(char *)shmat(msg_info1,(void *)0,0);
		int *bla2=(int *)shmat(msg_info2,(void *)0,0);
		//printf("%d %d\n",msg_info1,msg_info2);
		printf("Enter the String\n");
		scanf("%s",bla1);
		printf("Enter the Numeral\n");
		scanf("%d",bla2);
		sleep(2); 
		shmdt(bla1);
		shmdt(bla2);
		sem_post(sem_str);
		
		
	}
	else
	{	wait(NULL);
		if(sem_wait(sem_str)<0)
		{
			sleep(2);
		}
		int msg_info1=shmget(kt1,500,0666 | IPC_CREAT);
		int msg_info2=shmget(kt2,500,0666 | IPC_CREAT);
		//printf("%d %d\n",msg_info1,msg_info2);
		char *bla1=(char *)shmat(msg_info1,(void *)0,0);
		int *bla2=(int *)shmat(msg_info2,(void *)0,0);
		printf("String is: %s Numeral is: %d\n",bla1,*(bla2));
		shmctl(msg_info1,IPC_RMID,NULL);
		shmctl(msg_info2,IPC_RMID,NULL);
		
	}
}
