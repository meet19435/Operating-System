#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <semaphore.h>
#include <sys/types.h>
int a;
pthread_mutex_t eat_fork[6];
pthread_t array_thread[6]; 
void *process_eat(int n)
{	int a=n;
	if(a==4)
	{
		pthread_mutex_lock(&eat_fork[0]);
		printf("P%d receives F%d\n",5,1);
		pthread_mutex_lock(&eat_fork[4]);
		printf("P%d receives F%d, F%d\n",a+1,1,a+1);
		sleep(2);
		pthread_mutex_unlock(&eat_fork[4]);
		pthread_mutex_unlock(&eat_fork[0]);

	}
	else
	{
		pthread_mutex_lock(&eat_fork[a]);
		printf("P%d receives F%d\n",a+1,a+1);
		pthread_mutex_lock(&eat_fork[((a+1)%5)]);
		printf("P%d receives F%d, F%d\n",(a+1),a+1,((a%5+2)));
		sleep(2);
		pthread_mutex_unlock(&eat_fork[a]);
		pthread_mutex_unlock(&eat_fork[((a+1)%5)]);	
	}	

	return NULL;
}
 int main()
 {	
 	int count_thread=0;
 	while(count_thread<5)
 	{
 		pthread_mutex_init(&eat_fork[count_thread],NULL);
 		count_thread=count_thread+1;
 	}
 	a=0;
 	for(count_thread=0;count_thread<5;count_thread++)
 	{
 		pthread_create(&array_thread[count_thread],NULL,(void *)process_eat,(int *)count_thread);
 		
 		
 	}
 	for(int count_thread1=0;count_thread1<5;count_thread1++)
 	{
 		pthread_join(array_thread[count_thread1],NULL);
 	}
 	int count_thread2=0;	
  	while(count_thread2<5)
 	{	
 		pthread_mutex_destroy(&eat_fork[count_thread2]);
 		count_thread2++;
 	}

 	return 0;
 }