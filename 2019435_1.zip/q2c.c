#include <stdio.h> 
#include <sys/ipc.h> 
#include <sys/msg.h>  
#include <string.h>
struct msg { 
	long category; 
	char mess[500]; 
} bla; 

int main() 
{ 
	key_t kt; 
	int msg_id; 
	kt = ftok("filetest.txt", 5); 
	msg_id = msgget(kt, 0666 | IPC_CREAT); 
	msgrcv(msg_id, &bla, sizeof(bla), 1, 0);
	while(1)
	{
		printf("%s ", bla.mess);
		long test1=msgrcv(msg_id, &bla, sizeof(bla), 1, 0);
		char test[50];
		strcpy(test,bla.mess);
		if(strcmp(test,"\n\n")==0)
		{
			//printf("\n");
			break;
		}
	}
	msgctl(msg_id, IPC_RMID, NULL); 

	return 0; 
} 
